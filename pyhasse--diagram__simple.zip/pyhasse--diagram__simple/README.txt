This is a wild hack, later I will refactor the code for jupyter notebooks.

- It works with python 3.13 :-)
- create a virtual environment
- install all modules with:
  ::
  
     pip install -r requirements.txt

- hddata.py from the pyhasse.core module contains some print statements,
  comment out the lines prevents the output or delete the lines from the html page.
  
- select a set from csvdata
- create a html-Output with:
  ::

     python hd3d_lib.py > test.html

- Start a simple server

  ::

     python -m http.server

- visit the file within a browser

